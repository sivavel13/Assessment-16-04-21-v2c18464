package Question5;

class stringReverse{
	
	void reverse(String InputString) {
		
		StringBuffer ReverseOP = new StringBuffer(InputString);
		ReverseOP.reverse();
		System.out.println(ReverseOP);		
	}
}
public class Question5 {

	public static void main(String[] args) {
		
		stringReverse obj1 = new stringReverse();
		obj1.reverse("Java is best");
		obj1.reverse("best is Java");
	}

}
