package Question1Comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class employee
{
	int Id;
	String Name;
	
	public employee(int id, String name) 
	{
		super();
		Id = id;
		Name = name;
	}	
}
public class Question1Comparator {

	public static void main(String[] args) {
		ArrayList<employee> emplo = new ArrayList<employee>();
		emplo.add(new employee(103, "Tom"));
		emplo.add(new employee(174, "Tony"));
		emplo.add(new employee(122, "Stark"));		
		
		System.out.println("Id comparator");
		
		Collections.sort(emplo,new IdCompare());  
	
		for(employee e1: emplo){  
			System.out.println(e1.Id+" "+e1.Name);  
			}
		System.out.println("Name comparator");
		
		Collections.sort(emplo,new IdCompare()); 
		
		for(employee e2: emplo){  
			System.out.println(e2.Id+" "+e2.Name);  
			}
	}
}
class IdCompare implements Comparator<employee>
{
	public int compare(employee o1, employee o2) {
	employee E1 = (employee) o1;
	employee E2 = (employee) o2;
			
	if (E1.Id == E2.Id) {
		return 1;
	}
	else if(E1.Id > E2.Id) {
		return 0;
	}
	else {
		return -1;
	}
}
}
class NameComparator implements Comparator<employee>
{  
	public int compare(employee s1,employee s2)
	{  
		return s1.Name.compareTo(s2.Name);  
	}  
}  
