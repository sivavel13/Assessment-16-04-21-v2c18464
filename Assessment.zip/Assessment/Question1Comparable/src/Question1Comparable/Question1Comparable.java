package Question1Comparable;

import java.util.ArrayList;
import java.util.Collections;

class Student implements Comparable<Student>
{	
	int rollno;  
	String name;  
	int age;  
	Student(int rollno,String name,int age)
	{
		
		this.rollno=rollno;  
		this.name=name;  
		this.age=age;  
	}  
	public int compareTo(Student st){  
		if(age==st.age)  
			return 0;  
		else if(age>st.age)  
			return 1;  
		else  
			return -1;  
	}  
} 
public class Question1Comparable {

	public static void main(String[] args) {
		ArrayList<Student> al=new ArrayList<Student>();  
		al.add(new Student(11,"Tom",32));  
		al.add(new Student(23,"Stark",45));  
		al.add(new Student(13,"Peter",18));  
		  
		Collections.sort(al);  
		for(Student s:al){  
		System.out.println(s.rollno+" "+s.name+" "+s.age);  
		}  
	}

}
