package Question7;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class Question7 {

	public static void main(String[] args) {
	      String input = "Java is have Oops and Java very securd and have spring boot framework also..";
	      input = input.toLowerCase();

	      String[] strArray = input.split(" ");
	      List<String> repeatedWords = new ArrayList<>();

	      HashSet<String> uniqueWords = new HashSet<>();
	      
	      for(String str : strArray)
	      {
	          if (!uniqueWords.add(str))
	            repeatedWords.add(str);
	      }
	      System.out.println(repeatedWords);
	 }
}
